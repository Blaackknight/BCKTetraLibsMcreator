Blockly.Extensions.register('custom_permission_variables',function () {
    this.getInput("permissionvar").appendField(new Blockly.FieldDropdown(getVariablesOfType("String")), 'PERMISSIONVAR');
});