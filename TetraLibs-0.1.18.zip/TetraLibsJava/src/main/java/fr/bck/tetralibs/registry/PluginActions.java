package fr.bck.tetralibs.registry;

import net.mcreator.ui.MCreator;
import net.mcreator.ui.action.ActionRegistry;

public class PluginActions extends ActionRegistry {
    public PluginActions(MCreator mcreator) { super(mcreator); }
}
