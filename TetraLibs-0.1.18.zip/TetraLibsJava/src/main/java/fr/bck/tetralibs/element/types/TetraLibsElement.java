package fr.bck.tetralibs.element.types;

public interface TetraLibsElement {
}
